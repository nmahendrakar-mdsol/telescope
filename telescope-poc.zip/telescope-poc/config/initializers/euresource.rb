require 'euresource'

EUREKA_STAGE = ENV['EUREKA_STAGE'] || Rails.env unless defined?(EUREKA_STAGE)
APP_UUID = ENV['MAUTH_APP_UUID'] || 'fb17460e-9868-11e1-8399-0090f5ccb4d3' unless defined?(APP_UUID)


Euresource.configure do
  eureka_url = ENV['EUREKA_URL'] || 'http://localhost:9292'
  deployment_base_uri = ENV['EUREKA_DEPLOYMENT_BASEURI'] || 'http://localhost:3000'
  mauth_url = ENV['MAUTH_URL'] || 'http://localhost:7000'
  mauth_private_key = ENV['PRIVATE_KEY'] || "-----BEGIN RSA PRIVATE KEY-----
MIIEpQIBAAKCAQEA0+eZ7V7yLCtVNmV6BGmhaWXOWZ9BDn8kVMFHNxLHxmiLI8kq
l0LYYQGn9LrIa+zvUTiUSCfC/6gi/l0EYOUZ+j91/B77KAVTzgfykxzhhQ0qOyA2
zdiVrgvSZ/MdpXAgSaX38KJrSeUqEkVDVBjAjnGBOpZiinHOozvAwgJ2Ye/vIoj1
akqR5rnMQPA7PrBCh1mjaT8RNRoZ/JLqeqBBQ5eTOqEBbaysinFglGD83iBCJR87
uclt3/Yq8Skc7fW7OpgmTqk/GoPgvvZJsRgmF/1s9qamz19MQs+FSILesFz4yhPz
79NNLQ0gFZjtAoTBmBNb4T9pzgB2ChNn4IIcawIDAQABAoIBACxJjkkm+9QxZkjN
IphDf2Gozly6xP0Do5M3Jewjt68G8HWVOJqOdOypTPIAC51K0qWV/p+p97445L9m
r2CU4T4E/2KnEvTFUEOSM6d9dMC7BKWA0RNqfbX3cI0bKYoHCih6UHxxZZz3ETjq
Uu0Dk1Lx9AFLpuKqcHZ7KYkivJ0xB7B2O16fKUiZuvq4NhCw3f2xBh7TolYzALHn
+b6+i3a65xfzOkDlCOYdsRgZRZXccwO99I+EDc2n1fMdPgM9NekoXoKFxqlVxRYI
WO/jRoNNeS+sfyPzvKv27g/PNgBsf1QaWT9SEJNIbX+iG0qHGIYTxDakxTH8ocwV
g2vJidECgYEA908Wg5oglJD38w8pUrdCv1/5QARAqkyr31RJMhSENIvAZBiWnJxH
FWqNu3FMRqHcgzdOpZdHpTz6T4eGR2RAPeLzHXPleMSZnNJCE+PUXgFbp5t6umNh
a/sxbG0WKuKWnYlP27CAZLoXteN2Bpqz1U2/qX7lsdXTMvjNBexn8nMCgYEA21n/
26PSJbXX6SXBb6R5QXdG5feavh6gOjqtC/MMEM5fxouUCyPVguFXOLNE5rJZTEeQ
2N5oMNvYoiWQDE9amKRTTvauvquoZKLelNscOcBlPirASj0GhJwa1c0tdUq1q7QE
FWAQNFy8ZSExEZFul8BQGlTgB5NdbkQRtEJ4mCkCgYEAvCh6EqqDO0WIwG66m+o+
aGhWtPQHVwp6gbIY9ndRlsD1IbLrdEAafRrSttgelmaz5UmBFs+gfQGF2FheO5b0
oaE4IyJ4Zof976ixCXz/qH4UA9NxbroJ9yPomHvur7Yxra45CgahyQEk5QgoViIB
zLoYppabn8/1ngRZyLXy6C0CgYEArL3Mo5D4nt/8v8wO8LfLEgY33ETJJS4DKrgo
rP9johyUCkzDcp5ut5p0UN/ExBTyBANcC53i2Y9YpCEGttsLUqgeP1I/PUL74vzs
YrfHG6frUzDhq9UxO9+ftn3Vbcg/F5A1owu61zGs38tq1BX+zR0TOBldMDoaWwra
EmZCiDkCgYEAvZT9wpSy9w7WHate9UHDEv4CFOtY2Rdfjf6KQF4m8m9f5kC5gjtF
EU2lhGd+oK6G5eZbpoUXVCpurYL7LGqqcPfNejuhE80u4suP52nxk5M/gj7Owd8h
9Fp2TvO2sxmsZzv0uNFfvskgzG2V8Dd1qn4fKrppF8jC1cNLEypzL6o=
-----END RSA PRIVATE KEY-----
"
  entitystore = ENV['ENTITYSTORE'] || 'file:cache/rack/body'
  metastore = ENV['METASTORE'] || 'file:cache/rack/meta'

  config.stage_defaults do |defaults|
    defaults.deployment_base_uri(deployment_base_uri)

    defaults.mauth(mauth_url) do |mauth_config|
      mauth_config.app_uuid(APP_UUID)
      mauth_config.private_key(mauth_private_key)
    end

    defaults.use MAuth::Faraday::RequestSigner, defaults.mauth_config

    cache_config = { entitystore: entitystore, metastore: metastore }
    defaults.use FaradayMiddleware::RackCompatible, Eureka::Client::CacheMiddleware, cache_config

    if Rails.env != 'production'
      defaults.develop_mode(true)

      mocked_api_documents = Dir["#{Rails.root}/spec/support/fixtures/*.yml"].map do |f|
        YAML.load_file(f)
      end

      mocked_resources = [
        'apps',
        'configuration_type_roles',
        'configuration_types',
        'grants',
        'protected_resource_types',
        'role_assignments'
      ]

      fake_middleware_classes = mocked_resources.map do |resource_name|
        EurekaTools::ResourceMockerManager.class_for_mocked_resource(
          resource_name,
          mocked_api_documents)
      end

      config.stage('http://eureka.example.com', :remote) do |builder|
        builder.mock_api_deployments(mocked_api_documents)
        builder.resources(mocked_resources)

        fake_middleware_classes.each do |fake_middleware|
          builder.use(fake_middleware)
        end
      end
    end
  end

  config.stage(eureka_url, EUREKA_STAGE)
end
