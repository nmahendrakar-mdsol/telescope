require 'authorization_state_source'

class AuthorizationState
  include ActiveModel::Model

  RecordInvalid = Class.new(StandardError)
  UnableToUpdate = Class.new(StandardError)

  attr_accessor :app_uuid,
                :app_name,
                :updated_at,
                :available_resources,
                :available_operations,
                :current_authorization_state

  alias_attribute :id,
                  :app_uuid

  class << self
    def find_or_create!(app_uuid)
      result = Rails.cache.read(app_uuid) || new(app_uuid: app_uuid)
      result.save! unless result.persisted?
      result
    end

    def all
      keys = Rails.cache.read('keys') || []

      keys.map { |key| Rails.cache.read(key) }.compact
    end
  end

  def save!
    fetch!
    @persisted = true
    @updated_at = Time.now.utc
    add_to_cache
    self
  end

  def update_authorization_state!(desired_authorization_state)
    AuthorizationStateSource.manage_authorization_state!(
      app_uuid,
      desired_authorization_state: desired_authorization_state)
    self
  rescue AuthorizationStateSource::UnexpectedState => e
    raise UnableToUpdate, e.message
  end

  def destroy
    @app_name = nil
    @available_resources = nil
    @available_operations = nil
    @current_authorization_state = nil

    @persisted = false
    remove_from_cache
    self
  end

  def persisted?
    !!@persisted
  end

  def attributes
    {
      app_uuid: app_uuid,
      app_name: app_name,
      available_resources: available_resources,
      available_operations: available_operations,
      current_authorization_state: current_authorization_state
    }
  end

  def reload
    destroy
    save!
  end

  def available_resources
    @available_resources ||= AuthorizationStateSource.all_resources
  end

  def available_operations
    @available_operations ||= AuthorizationStateSource.cached_operations
  end

  def current_authorization_state
    @current_authorization_state ||= AuthorizationStateSource.current_authorization(app_uuid)
  end

  def app_name
    @app_name ||= AuthorizationStateSource.app_name(app_uuid)
  end

  def ==(other)
    return false unless other.is_a?(AuthorizationState)

    attributes == other.attributes
  end

  private

  def fetch!
    current_authorization_state
    app_name
    available_resources
    available_operations
  end

  def add_to_cache
    current_keys = Rails.cache.read('keys') || []

    if current_keys.is_a?(String)
      current_keys = [current_keys]
    end

    new_keys = current_keys | [app_uuid]
    Rails.cache.write('keys', new_keys, expires_in: 1.month)
    Rails.cache.write(app_uuid, self, expires_in: 1.month)
  end

  def remove_from_cache
    current_keys = Rails.cache.read('keys') || []

    if current_keys.is_a?(String)
      current_keys = [current_keys]
    end

    return unless current_keys.include?(app_uuid)

    new_keys = current_keys - [app_uuid]
    Rails.cache.write('keys', new_keys, expires_in: 1.month)
    Rails.cache.delete(app_uuid)
  end
end
