# Telescope

## Introduction

Telescope is a fullstack service that provides a UI for viewing and configuring
apps' authorization on collections of resources in
[Dalton](https://github.com/mdsol/dalton).

### **Telescope is not yet production-ready. See [Next Steps](#Next-Steps)**

Users provide an app's uuid in the UI. Telescope generates a page that describes
the app's authorization on collections of resources. The description is
formatted both visually and in JSON.

Telescope provides a separate page for editing the app's authorization. This
page displays the authorization both visually and as JSON, but access can be
edited either way.

For example, to authorize the `read` operation for `studies`, the user can
select the `read` operation in the dropdown and check the `studies` checkbox.
Alternatively, the user can modify the JSON with `"read": ["studies"]` and click
"Load Authorization JSON". Clicking "Update Authorization State" will apply the
changes.

It's recommended to commit the authorization JSON your app needs to function to
your app's repo. Machine-readable authorization requirements will make it easier
to deploy your app, set up your app in a new environment, and automate changes
to your app's required authorization.

## How Telescope Works

Telescope's backend is fairly straightforward.

There are two main aspects: viewing authorization state and updating
authorization state.

### Viewing Authorization State

To view authorization state, Telescope makes a series of Dalton calls and
massages the data into a format that's easier to work with.

Here is the process:

1. Fetch all Role Assignments for the given app
2. Filter out Role Assignments that are _not_ for resource collections. This
   means filtering Role Assignments with an `operable_uri` that does not match
   `com:mdsol:<resource>_collection:all`
3. For each Role Assignment: 
   1. Determine the set of permissions that the Configuration Type Role provides
   2. Determine the set of resources that the Role Assignment authorizes
4. Combine the data from each Role Assignment into a full map of permissions to
   authorized resources


### Updating Authorization State

To update authorization state, Telescope makes a series of Dalton calls to
create Grants and delete Role Assignments.

Here is the process:

1. Generate the Grant parameters for the desired authorization state
   [viewing](#Viewing-Authorization-State))
2. Fetch the Role Assignment parameters for the current authorization state
3. Calculate Role Assignments that need to be deleted and Grants that need to be
   created
4. Create the necessary Grants
5. Delete the necessary Role Assignments

## Next Steps

- Authorization
  - Determine appropriate authorization scheme
  - Gate update access to authorized users in red
  - This should probably use the same authorization rules as Medistrano
- Features
  - Expose API that accepts authorization JSON
  - Integrate Telescope authorization with GoCD (app deployments automatically
    configure authorization in a stage using the app's committed authorization
    JSON)
- Safety
  - UX
    - Add confirmation dialogue before updates
    - Add authorization diff for updates
  - Testing
    - Test more failure cases
    - Request specs
    - End-to-end tests with the UI
  - Smoke tests
- Dalton Work
  - Add `operator_uri` parameter to Grant#index and update Telescope accordingly

## Contact

Please see the [factbook](./factbook.json).
