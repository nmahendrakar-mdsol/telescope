require 'resource_tree'

module ProtectedResourceTypesHelper
  def all_resources
    hash_tree = protected_resource_types.each_with_object({}) do |prt, memo|
      next unless prt.parents.empty?

      resource = prt.oid

      accessible_resources = accessible_resources_for_resource(resource).to_h
      memo.merge!(accessible_resources)
    end

    ResourceTree.new(hash_tree)
  end

  def accessible_resources_for_resource(resource)
    hash_tree = { resource => accessible_resources_for_resource_helper(resource) }
    ResourceTree.new(hash_tree)
  end

  private

  def accessible_resources_for_resource_helper(resource)
    resource = resource.oid if resource.is_a?(FakeProtectedResourceType)

    children = protected_resource_types.select do |prt|
      prt.parents.include?(resource)
    end.map(&:oid)

    children.each_with_object({}) do |child, memo|
      memo[child] = accessible_resources_for_resource_helper(child)
    end
  end

  def protected_resource_types
    @protected_resource_types ||=
      begin
        real_protected_resource_types.each_with_object({}) do |prt, memo|
          fake_prt = FakeProtectedResourceType.new(prt.attributes)

          memo_key = fake_prt.oid
          memo[memo_key] = memo[memo_key].try(:merge, fake_prt) || fake_prt
        end.values.flatten
      end
  end

  def real_protected_resource_types
    @real_protected_resource_types ||= begin
      Rails.logger.info("Fetching protected resource types")
      Euresource::ProtectedResourceTypes.get_all
    end
  end

  # Some protected resource types hide their relationships because of mismatched
  # data. For example, 'configuration_type_roles' is not a parent to
  # 'permissions', but 'configuration_type_roles_collection' is a parent to
  # 'permissions_collection'
  class FakeProtectedResourceType
    attr_accessor :oid, :parents, :members

    def initialize(params)
      params = params.with_indifferent_access
      @oid = if params[:oid].end_with?('_collection')
               params[:oid].delete_suffix('_collection')
             else
               params[:oid]
             end

      @parents = (params[:parents] || []).map do |parent_oid|
        parent_oid.delete_suffix('_collection')
      end

      @members = (params[:members] || []).map do |member_oid|
        member_oid.delete_suffix('_collection')
      end
    end

    def merge(other_fake_prt)
      raise unless oid == other_fake_prt.oid

      @parents |= other_fake_prt.parents
      @members |= other_fake_prt.members

      self
    end
  end
end
