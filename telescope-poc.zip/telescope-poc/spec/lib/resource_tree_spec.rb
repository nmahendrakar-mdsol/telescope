require 'rails_helper'
require 'resource_tree'

RSpec.describe ResourceTree do
  describe '.initialize' do
    it 'accepts a hash description of a tree' do
      hash_tree = { SecureRandom.uuid => {} }
      expect { ResourceTree.new(hash_tree) }.to_not raise_error
    end
  end

  describe '#to_h' do
    let(:hash_tree) { { SecureRandom.uuid => { SecureRandom.uuid => {} } } }
    let(:resource_tree) { ResourceTree.new(hash_tree) }

    it 'returns the hash description of the tree' do
      expect(resource_tree.to_h).to eq(hash_tree)
    end
  end

  describe '#to_a' do
    let(:hash_tree) { { SecureRandom.uuid => { SecureRandom.uuid => {} } } }
    let(:resource_tree) { ResourceTree.new(hash_tree) }

    it 'returns an array of unique nodes in the tree' do
      unique_nodes = []

      hash_tree.deep_transform_keys { |node| unique_nodes.push(node) }

      expect(resource_tree.to_a.sort).to eq(unique_nodes.sort)
    end
  end

  describe '#==' do
    let(:hash_tree) { { SecureRandom.uuid => {} } }
    let(:resource_tree) { ResourceTree.new(hash_tree) }

    context 'comparing to a hash' do
      context 'if they represent the same tree' do
        let(:comparison) { hash_tree }

        it 'returns true' do
          expect(resource_tree == comparison).to eq(true)
        end
      end

      context 'if they do not represent the same tree' do
        let(:comparison) { { SecureRandom.uuid => {} } }

        it 'returns false' do
          expect(resource_tree == comparison).to eq(false)
        end
      end
    end

    context 'comparing to a ResourceTree' do
      context 'if they represent the same tree' do
        let(:comparison) { ResourceTree.new(hash_tree) }

        it 'returns true' do
          expect(resource_tree == comparison).to eq(true)
        end
      end

      context 'if they do not represent the same tree' do
        let(:comparison) { ResourceTree.new(SecureRandom.uuid => {}) }

        it 'returns false' do
          expect(resource_tree == comparison).to eq(false)
        end
      end
    end
  end
end
