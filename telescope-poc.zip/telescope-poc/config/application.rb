require_relative 'boot'

require "rails"
require "rails/all"
require "active_model/railtie"
require "active_job/railtie"
require "action_controller/railtie"
require "action_view/railtie"
require "sprockets/railtie"
require "devise"

Bundler.require(*Rails.groups)

module Telescope
  class Application < Rails::Application
    # Initialize configuration defaults for originally generated Rails version.
    config.load_defaults 5.2

    # Settings in config/environments/* take precedence over those specified here.
    # Application configuration can go into files in config/initializers
    # -- all .rb files in that directory are automatically loaded after loading
    # the framework and any gems in your application.

    # Don't generate system test files.
    config.generators.system_tests = nil

    if Rails.env.production?
      config.secret_key_base = ENV['SECRET_KEY_BASE'] || raise(IOError, 'Must configure a secret key in production!')
    else
      config.secret_key_base = 'foobarbaz'
    end

    config.action_controller.perform_caching = true

    config.cache_store = :memory_store
    
    config.generators do |g|
      g.orm :devise
    end

    config.public_file_server.headers = {
      'Cache-Control' => "public, max-age=#{2.days.to_i}"
    }
  end
end
