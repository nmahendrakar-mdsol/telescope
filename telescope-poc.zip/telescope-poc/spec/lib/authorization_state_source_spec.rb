require 'rails_helper'
require 'authorization_state_source'

RSpec.describe AuthorizationStateSource do
  describe '.app_name' do
    context 'when the app exists' do
      let(:app) { create(:app) }

      it 'returns the name of the app' do
        expect(AuthorizationStateSource.app_name(app.uuid)).to eq(app.name)
      end
    end

    context 'when the app does not exist' do
      let(:app_uuid) { SecureRandom.uuid }

      it 'returns the app uuid' do
        expect(AuthorizationStateSource.app_name(app_uuid)).to eq(app_uuid)
      end
    end
  end

  describe '.current_authorization' do
    let(:app_uri) { randomized_uri_for(:apps) }
    let(:app_uuid) { Mdsol::URI.parse(app_uri).uuid }

    context 'when the app is directly authorized on a resource collection' do
      let(:resource) { create(:protected_resource_type).oid }
      let(:operation) { SecureRandom.uuid }
      let(:role) do
        create(:configuration_type_role, permissions: [permission_for_operation(operation)])
      end

      before do
        create(:role_assignment,
          operator_uri: app_uri,
          role_uri: Mdsol::URI.generate(role).to_s,
          operable_uri: collection_uri(resource))
      end

      it 'returns a representation of the authorization' do
        expected_result = { operation => [resource] }

        expect(AuthorizationStateSource.current_authorization(app_uuid)).to match expected_result
      end

      context 'and the app is indirectly authorized on a resource collection' do
        let!(:child_resource) { create(:protected_resource_type, parents: [resource]).oid }

        it 'returns a representation of the authorization' do
          expect(
            AuthorizationStateSource.current_authorization(app_uuid)
          ).to match(operation => match_array([resource, child_resource]))
        end
      end
    end

    context 'when the app is not authorized on a resource collection' do
      it 'returns a representation of the authorization' do
        expected_result = {}

        expect(AuthorizationStateSource.current_authorization(app_uuid)).to eq(expected_result)
      end
    end

    context 'when the app is authorized on a specific resource' do
      before do
        create(:role_assignment,
          operator_uri: app_uri,
          operable_uri: randomized_uri_for(:resource))
      end

      it 'returns a representation of the authorization' do
        expected_result = {}

        expect(AuthorizationStateSource.current_authorization(app_uuid)).to eq(expected_result)
      end
    end
  end

  describe '.cached_operations' do
    it 'returns an empty array' do
      expect(AuthorizationStateSource.cached_operations).to eq([])
    end

    context 'after calculating the current authorization of an app' do
      let(:app_uri) { randomized_uri_for(:apps) }
      let(:app_uuid) { Mdsol::URI.parse(app_uri).uuid }

      let(:operation) { SecureRandom.uuid }
      let(:role) do
        create(:configuration_type_role, permissions: [permission_for_operation(operation)])
      end

      before do
        create(:role_assignment,
          operator_uri: app_uri,
          role_uri: Mdsol::URI.generate(role).to_s)

        AuthorizationStateSource.current_authorization(app_uuid)
      end

      it 'returns the operations that the app is authorized on' do
        expect(AuthorizationStateSource.cached_operations).to eq([operation])
      end

      context 'and calculating the authorization of an app with different operations' do
        let(:other_app_uri) { randomized_uri_for(:apps) }
        let(:other_app_uuid) { Mdsol::URI.parse(other_app_uri).uuid }

        let(:other_operation) { SecureRandom.uuid }
        let(:other_role) do
          create(:configuration_type_role, permissions: [permission_for_operation(other_operation)])
        end

        before do
          create(:role_assignment,
            operator_uri: other_app_uri,
            role_uri: Mdsol::URI.generate(other_role).to_s)

          AuthorizationStateSource.current_authorization(other_app_uuid)
        end

        it 'returns the operations that the app is authorized on' do
          expect(
            AuthorizationStateSource.cached_operations
          ).to match_array([operation, other_operation])
        end
      end
    end
  end

  describe '.manage_authorization_state!' do
    let(:app_uuid) { create(:app).uuid }
    let(:app_uri) { Mdsol::URI.generate(app_uuid, resource: :apps).to_s }

    before { create(:configuration_type, parent_uri: Mdsol::URI.generate(APP_UUID, resource: :apps).to_s) }

    context 'when the app is assigned to a specific resource' do
      let(:resource) { SecureRandom.uuid }
      let(:resource_uri) { randomized_uri_for(resource) }
      let(:operation) { SecureRandom.uuid }

      context 'with a non-telescope role' do
        let(:role) { create(:configuration_type_role, permissions: [permission_for_operation(operation)]) }
        let(:role_uri) { Mdsol::URI.generate(role).to_s }

        before { create(:role_assignment, operator_uri: app_uri, role_uri: role_uri, operable_uri: resource_uri) }

        context 'and the desired authorization state includes the resource collection' do
          let(:desired_authorization_state) { { operation => [resource] } }

          it 'does not destroy the assignment to the specific resource' do
            expect {
              AuthorizationStateSource.manage_authorization_state!(app_uuid, desired_authorization_state: desired_authorization_state)
            }.to_not change {
              role_assignment_exists?(app_uri, role_uri, resource_uri)
            }.from(true)
          end

          it 'creates an assignment to the resource collection' do
            telescope_role_uri = AuthorizationStateSource.role_uri_for_operation!(operation)

            expect {
              AuthorizationStateSource.manage_authorization_state!(app_uuid, desired_authorization_state: desired_authorization_state)
            }.to change {
              role_assignment_exists?(app_uri, telescope_role_uri, collection_uri(resource))
            }.from(false).to(true)
          end
        end

        context 'and the desired authorization state does not include the resource collection' do
          let(:other_resource) { SecureRandom.uuid }
          let(:desired_authorization_state) { { operation => [other_resource] } }

          it 'does not destroy the assignment to the specific resource' do
            expect {
              AuthorizationStateSource.manage_authorization_state!(app_uuid, desired_authorization_state: desired_authorization_state)
            }.to_not change {
              role_assignment_exists?(app_uri, role_uri, resource_uri)
            }.from(true)
          end

          it 'does not create an assignment to the resource collection' do
            expect {
              AuthorizationStateSource.manage_authorization_state!(app_uuid, desired_authorization_state: desired_authorization_state)
            }.to_not change {
              role_assignment_exists?(app_uri, role_uri, collection_uri(resource))
            }.from(false)
          end
        end
      end
    end

    context 'when the app is assigned to a resource collection' do
      let(:resource) { SecureRandom.uuid }
      let(:operation) { SecureRandom.uuid }

      context 'with a telescope role' do
        let(:role_uri) { AuthorizationStateSource.role_uri_for_operation!(operation) }

        before { create(:role_assignment, operator_uri: app_uri, role_uri: role_uri, operable_uri: collection_uri(resource)) }

        context 'and the desired authorization state includes that collection' do
          let(:desired_authorization_state) { { operation => [resource] } }

          it 'does not destroy the assignment to the resource collection' do
            expect {
              AuthorizationStateSource.manage_authorization_state!(app_uuid, desired_authorization_state: desired_authorization_state)
            }.to_not change {
              role_assignment_exists?(app_uri, role_uri, collection_uri(resource))
            }.from(true)
          end
        end

        context 'and the desired authorization state does not include that collection' do
          let(:desired_authorization_state) { {} }

          it 'destroys the assignment to that resource collection' do
            expect {
              AuthorizationStateSource.manage_authorization_state!(app_uuid, desired_authorization_state: desired_authorization_state)
            }.to change {
              role_assignment_exists?(app_uri, role_uri, collection_uri(resource))
            }.from(true).to(false)
          end
        end
      end

      context 'with a non-telescope role' do
        context 'with a single permission' do
          let(:role) { create(:configuration_type_role, permissions: [permission_for_operation(operation)]) }
          let(:role_uri) { Mdsol::URI.generate(role).to_s }

          before { create(:role_assignment, operator_uri: app_uri, role_uri: role_uri, operable_uri: collection_uri(resource)) }

          context 'and the desired authorization state includes that collection' do
            let(:desired_authorization_state) { { operation => [resource] } }

            it 'destroys the assignment for the non-telescope role' do
              expect {
                AuthorizationStateSource.manage_authorization_state!(app_uuid, desired_authorization_state: desired_authorization_state)
              }.to change {
                role_assignment_exists?(app_uri, role_uri, collection_uri(resource))
              }.from(true).to(false)
            end

            it 'creates a new assignment with the telescope role' do
              telescope_role_uri = AuthorizationStateSource.role_uri_for_operation!(operation)

              expect {
                AuthorizationStateSource.manage_authorization_state!(app_uuid, desired_authorization_state: desired_authorization_state)
              }.to change {
                role_assignment_exists?(app_uri, telescope_role_uri, collection_uri(resource))
              }.from(false).to(true)
            end
          end

          context 'and the desired authorization state does not include that collection' do
            let(:desired_authorization_state) { {} }

            it 'destroys the assignment to that resource collection' do
              expect {
                AuthorizationStateSource.manage_authorization_state!(app_uuid, desired_authorization_state: desired_authorization_state)
              }.to change {
                role_assignment_exists?(app_uri, role_uri, collection_uri(resource))
              }.from(true).to(false)
            end
          end
        end

        context 'with multiple permissions' do
          let(:other_operation) { SecureRandom.uuid }

          let(:role) do
            create(
              :configuration_type_role,
              permissions: [
                permission_for_operation(operation),
                permission_for_operation(other_operation)
              ]
            )
          end
          let(:role_uri) { Mdsol::URI.generate(role).to_s }

          before { create(:role_assignment, operator_uri: app_uri, role_uri: role_uri, operable_uri: collection_uri(resource)) }

          context 'and the desired authorization state includes all permissions on that collection' do
            let(:desired_authorization_state) { { operation => [resource], other_operation => [resource] } }

            it 'destroys the assignment for the non-telescope role' do
              expect {
                AuthorizationStateSource.manage_authorization_state!(app_uuid, desired_authorization_state: desired_authorization_state)
              }.to change {
                role_assignment_exists?(app_uri, role_uri, collection_uri(resource))
              }.from(true).to(false)
            end

            it 'creates new assignments with the telescope roles' do
              telescope_role_uri = AuthorizationStateSource.role_uri_for_operation!(operation)
              other_telescope_role_uri = AuthorizationStateSource.role_uri_for_operation!(other_operation)

              expect {
                AuthorizationStateSource.manage_authorization_state!(app_uuid, desired_authorization_state: desired_authorization_state)
              }.to change {
                [telescope_role_uri, other_telescope_role_uri].all? do |role_uri|
                  role_assignment_exists?(app_uri, role_uri, collection_uri(resource))
                end
              }.from(false).to(true)
            end
          end

          context 'and the desired authorization state includes one of the permissions on that collection' do
            let(:desired_authorization_state) { { operation => [resource] } }

            it 'destroys the assignment for the non-telescope role' do
              expect {
                AuthorizationStateSource.manage_authorization_state!(app_uuid, desired_authorization_state: desired_authorization_state)
              }.to change {
                role_assignment_exists?(app_uri, role_uri, collection_uri(resource))
              }.from(true).to(false)
            end

            it 'creates the correct assignment for the telescope role' do
              telescope_role_uri = AuthorizationStateSource.role_uri_for_operation!(operation)

              expect {
                AuthorizationStateSource.manage_authorization_state!(app_uuid, desired_authorization_state: desired_authorization_state)
              }.to change {
                role_assignment_exists?(app_uri, telescope_role_uri, collection_uri(resource))
              }.from(false).to(true)
            end
          end

          context 'and the desired authorization state does not include that collection' do
            let(:desired_authorization_state) { {} }

            it 'destroys the assignment for the non-telescope role' do
              expect {
                AuthorizationStateSource.manage_authorization_state!(app_uuid, desired_authorization_state: desired_authorization_state)
              }.to change {
                role_assignment_exists?(app_uri, role_uri, collection_uri(resource))
              }.from(true).to(false)
            end
          end
        end
      end
    end

    context 'when the app is not assigned to a resource collection' do
      let(:resource) { SecureRandom.uuid }
      let(:operation) { SecureRandom.uuid }
      let(:role_uri) { AuthorizationStateSource.role_uri_for_operation!(operation) }

      context 'and the desired authorization state includes that collection' do
        let(:desired_authorization_state) { { operation => [resource] } }

        it 'creates an assignment to that resource collection' do
          expect {
            AuthorizationStateSource.manage_authorization_state!(app_uuid, desired_authorization_state: desired_authorization_state)
          }.to change {
            role_assignment_exists?(app_uri, role_uri, collection_uri(resource))
          }.from(false).to(true)
        end
      end
    end

    context 'dogfooding' do
      let(:telescope_authorization) { JSON.parse(File.read(Rails.root.join('authorization.json'))) }
      let(:operations) { telescope_authorization.keys }

      it 'authorizes telescope correctly' do
        expect {
          AuthorizationStateSource.manage_authorization_state!(app_uuid, desired_authorization_state: telescope_authorization)
        }.to change {
          operations.all? do |operation|
            resources = telescope_authorization[operation]
            desired_role_uri = AuthorizationStateSource.role_uri_for_operation!(operation)

            resources.all? do |resource|
              role_assignment_exists?(app_uri, desired_role_uri, collection_uri(resource))
            end
          end
        }.from(false).to(true)
      end
    end
  end

  describe '.role_uri_for_operation!' do
    let(:operation) { SecureRandom.uuid }
    let!(:ct) do
      create(:configuration_type, parent_uri: Mdsol::URI.generate(APP_UUID, resource: :apps).to_s)
    end

    context 'when the telescope configuration type has a role for the operation' do
      let!(:role) do
        create(:configuration_type_role,
          configuration_type_uuid: ct.uuid,
          name: operation,
          permissions: [permission_for_operation(operation)])
      end

      it 'returns the role uri' do
        expected_result = Mdsol::URI.generate(role).to_s

        expect(AuthorizationStateSource.role_uri_for_operation!(operation)).to eq(expected_result)
      end
    end

    context 'when the telescope configuration type does not have a role for the operation' do
      it 'creates a role for the operation' do
        expect {
          AuthorizationStateSource.role_uri_for_operation!(operation)
        }.to change {
          roles = Euresource::ConfigurationTypeRole.get_all(configuration_type_uuid: ct.uuid)
          roles.any? do |role|
            role.name == operation && role.permissions = permission_for_operation(operation)
          end
        }.from(false).to(true)
      end

      it 'returns the role uri' do
        result = AuthorizationStateSource.role_uri_for_operation!(operation)
        role_uuid = Mdsol::URI.parse(result).uuid

        role = Euresource::ConfigurationTypeRole.get(role_uuid)

        expect(role.attributes).to include(
          'name' => operation,
          'permissions' => [permission_for_operation(operation)]
        )
      end
    end
  end
end
