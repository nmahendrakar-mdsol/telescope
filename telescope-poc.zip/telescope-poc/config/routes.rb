Rails.application.routes.draw do
  resources :authorization_states, except: [:new, :destroy]
  post 'authorization_states/:id/refresh',
    to: 'authorization_states#refresh', as: 'refresh_authorization_state'

  namespace :api, defaults: { format: :json } do
    resources :authorization_states, only: [:update]
  end

  root to: 'authorization_states#index'
end
