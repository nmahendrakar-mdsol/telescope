// const authorizationState = @authorization_state.to_json

function getOperationFieldset(operation) {
    const fieldsetName = operation + '_fieldset';
    return document.getElementsByName(fieldsetName)[0];
}

function showOperationFieldset(operation) {
    getOperationFieldset(operation).hidden = false;
}

function allOperationFieldsets() {
    const operationFieldsetsContainer = document.getElementById('operation_fieldsets');
    if (operationFieldsetsContainer == null) {
        return null;
    }

    return operationFieldsetsContainer.getElementsByClassName('operation_fieldset');
}

function showSelectedOperationFieldset() {
    const operationSelector = document.getElementById('operations_select');
    if (operationSelector == null) {
        return;
    }

    const selectedOperationName = operationSelector.value.trim();

    showOperationFieldset(selectedOperationName);
}

function hideAllOperationFieldsets() {
    const operationFieldsets = allOperationFieldsets();
    if (operationFieldsets == null) {
        return;
    }

    for (var i = 0; i < operationFieldsets.length; i++) {
        operationFieldsets[i].hidden = true;
    }
}

function onDescendantResources(resourceInput, func) {
    const resourceHierarchy = resourceInput.parentElement;
    const resources = resourceHierarchy.getElementsByClassName('operation_input');

    for (var i = 0; i < resources.length; i++) {
        const resource = resources[i];

        if (resource != resourceInput) {
            func(resource);
        }
    }
}

function checkDescendantResources(resourceInput) {
    onDescendantResources(resourceInput, function(resource) {
        if (resource.checked == false) {
            resource.checked = true;
        }

        if (resource.disabled == false) {
            resource.disabled = true;
        }
    });
}

function uncheckDescendantResources(resourceInput) {
    onDescendantResources(resourceInput, function(resource) {
        if (resource.checked == true) {
            resource.checked = false;
        }

        if (resource.disabled == true) {
            resource.disabled = false;
        }
    });
}

function checkAuthorizedResourcesForAuthorization(authorization) {
    if (typeof(authorization) == 'undefined' || authorization == null) {
        return;
    }

    // uncheck all currently checked boxes
    const allCheckboxes = document.getElementsByClassName('operation_input');
    for (i in allCheckboxes) {
        const checkbox = allCheckboxes[i];
        if (checkbox.checked) {
            checkbox.checked = false;
        }
    }

    for (operation in authorization) {
        const resources = authorization[operation];

        for (i in resources) {
            const resource = resources[i];
            const checkboxId = operation + '_' + resource;

            const checkboxElem = document.getElementById(checkboxId);

            if (checkboxElem != null && checkboxElem.checked == false) {
                checkboxElem.checked = true;
                checkDescendantResources(checkboxElem);
            }
        }
    }
}

function checkAuthorizedResources() {
    if (typeof(authorizationState) == 'undefined' || authorizationState == null) {
        return;
    }

    checkAuthorizedResourcesForAuthorization(authorizationState.current_authorization_state);
}

function enableDescendantCheckboxes() {
    const operationFieldsets = allOperationFieldsets();

    if (operationFieldsets == null) {
        return;
    }

    for (i = 0; i < operationFieldsets.length; i++) {
        const operationFieldset = operationFieldsets[i];

        const checkboxes = operationFieldset.getElementsByClassName('operation_input');

        for (j = 0; j < checkboxes.length; j++) {
            const checkbox = checkboxes[j];

            if (checkbox.disabled) {
                checkbox.disabled = false;
            }
        }
    }
}

function authorizationToJson(authorization) {
    const sortedKeys = Object.keys(authorization).sort();
    // new object to ensure sorted insertion order
    var sortedAuthorization = {};

    for (i in sortedKeys) {
        const key = sortedKeys[i];
        const sortedResources = authorization[key].sort();

        if (sortedResources.length > 0) {
            sortedAuthorization[key] = sortedResources;
        }
    }

    return JSON.stringify(sortedAuthorization, null, 4);
}

function generateAuthorizationFromFieldsets() {
    const operationFieldsets = allOperationFieldsets();
    if (operationFieldsets == null) {
        return null;
    }

    var authorization = {};

    for (i = 0; i < operationFieldsets.length; i++) {
        const operationFieldset = operationFieldsets[i];
        const operation = operationFieldset.children[0].id;

        if (typeof(authorization[operation]) == 'undefined') {
            authorization[operation] = [];
        }

        const checkboxes = operationFieldset.getElementsByClassName('operation_input');

        for (j = 0; j < checkboxes.length; j++) {
            const checkbox = checkboxes[j];

            if (checkbox.checked) {
                const resource = checkbox.value.trim();
                authorization[operation].push(resource);
            }
        }
    }

    return authorization;
}

function updateAuthorizationJson() {
    const authorization = generateAuthorizationFromFieldsets();

    if (typeof(authorization) == 'undefined' || authorization == null) {
        return;
    }

    const json = authorizationToJson(authorization);
    const authorizationJson = document.getElementById('authorization_json');
    authorizationJson.value = json;
}

function warnInput(inputElem) {
    inputElem.style.backgroundColor = 'red';

    const warningDiv = document.createElement('div');
    const warningMessage = document.createTextNode("Invalid JSON!");
    warningDiv.appendChild(warningMessage);

    inputElem.parentElement.insertBefore(warningDiv, inputElem.nextSibling);
}

function loadAuthorizationJson() {
    const authorizationJsonElem = document.getElementById('authorization_json');
    const authorizationJson = authorizationJsonElem.value.trim();
    var authorization;

    try {
        authorization = JSON.parse(authorizationJson);
    } catch (e) {
        if (e instanceof SyntaxError) {
            warnInput(authorizationJsonElem);
            return;
        } else {
            throw e;
        }
    }

    // Handle json with new operations
    const operations = Object.keys(authorization);
    for (var i = 0; i < operations.length; i++) {
        const operation = operations[i];

        const operationList = document.getElementById(operation);

        if (typeof(operationList) == 'undefined' || operationList == null) {
            addOperation(operation);
        }
    }

    checkAuthorizedResourcesForAuthorization(authorization);
}

function addOperationDropdown(operation) {
    const dropdownMenu = document.getElementById('operations_select');
    const currentlySelectedOperation = dropdownMenu.options[dropdownMenu.selectedIndex].text;
    const currentOperations = dropdownMenu.children;

    // Check if the operation is already added
    for (var i = 0; i < currentOperations.length; i++) {
        if (currentOperations[i] == operation) {
            return;
        }
    }

    const newOperation = document.createElement('option');
    newOperation.text = operation.trim();

    // add new operation element to the mix and sort by operation value
    const operationArray = Array.from(currentOperations);
    operationArray.push(newOperation);
    const sortedNewOperations = operationArray.sort(function(a, b) {
        if (a > b) {
            return -1;
        }
        if (b > a) {
            return 1;
        }
        return 0;
    });

    dropdownMenu.innerHTML = '';
    var shouldSelectedOperationIndex;

    for (var j = 0; j < sortedNewOperations.length; j++) {
        const operationElem = sortedNewOperations[j];
        dropdownMenu.appendChild(operationElem);

        // Set the current selection to what it was before
        if (operationElem.text == currentlySelectedOperation) {
            shouldSelectedOperationIndex = j;
        }
    }

    dropdownMenu.selectedIndex = shouldSelectedOperationIndex;
}

function generateResourceCheckboxes(operation, children) {
    var childResources = Object.keys(children).sort();

    var result = [];

    for (var i = 0; i < childResources.length; i++) {
        const child = childResources[i];
        const checkboxId = operation + '_' + child;

        const newInputElement = document.createElement('input');
        const newInputLabel = document.createElement('label');
        newInputLabel.htmlFor = checkboxId;
        newInputLabel.innerText = child;

        newInputElement.type = 'checkbox';
        newInputElement.className = 'operation_input';
        newInputElement.name = 'operation[' + operation + '][]';
        newInputElement.id = checkboxId;
        newInputElement.value = child;

        const newListElement = document.createElement('li');
        newListElement.appendChild(newInputElement);
        newListElement.appendChild(newInputLabel);

        const grandchildren = children[child];
        if (Object.keys(grandchildren).length > 0) {
            const grandchildrenList = document.createElement('ul');

            const grandchildrenResources = generateResourceCheckboxes(operation, grandchildren);

            for (var j = 0; j < grandchildrenResources.length; j++) {
                const grandchild = grandchildrenResources[j];
                grandchildrenList.appendChild(grandchild);
            }

            newListElement.appendChild(grandchildrenList);
        }

        result.push(newListElement);
    }

    return result;
}

function addOperationFieldset(operation) {
    const operationFieldsets = document.getElementById('operation_fieldsets');

    const newOperationFieldset = document.createElement('fieldset');
    newOperationFieldset.name = operation + '_fieldset';
    newOperationFieldset.className = 'operation_fieldset';
    newOperationFieldset.hidden = true;

    const newResourceList = document.createElement('ul');
    newResourceList.id = operation;

    newOperationFieldset.appendChild(newResourceList);

    const availableResources = authorizationState.available_resources['hash_tree'];

    const resourceCheckboxes = generateResourceCheckboxes(operation, availableResources);

    for (var i = 0; i < resourceCheckboxes.length; i++) {
        const resourceCheckbox = resourceCheckboxes[i];
        newResourceList.appendChild(resourceCheckbox);
    }

    operationFieldsets.appendChild(newOperationFieldset);
    addCallbacksToCheckboxes(newOperationFieldset);
}

function addOperation(operation) {
    addOperationDropdown(operation);
    addOperationFieldset(operation);

    const dropdownText = document.getElementById('operations_add_text');
    dropdownText.value = '';
}

function addCallbacksToCheckboxes(operationFieldset) {
    const operationInputs = operationFieldset.getElementsByClassName('operation_input');

    for (var i = 0; i < operationInputs.length; i++) {
        const inputElem = operationInputs[i];

        // Add the check cascade callback
        inputElem.addEventListener('change', function(event) {
            // If it's checked, that means the change was checking the
            // box. If it's not checked, the change was unchecking.
            if (event.target.checked) {
                checkDescendantResources(event.target);
            } else {
                uncheckDescendantResources(event.target);
            }
        });

        // Add the json generation callback
        inputElem.addEventListener('change', function(event) {
            updateAuthorizationJson();
        });
    }
}

function beforeSubmit() {
    // Enable descendant checkboxes so the full hierarchy is submitted in the form
    enableDescendantCheckboxes();
}

function initializeEdit() {
    document.addEventListener('turbolinks:load', function() {
        // Hide the unselected operation fieldsets
        hideAllOperationFieldsets();
        showSelectedOperationFieldset();

        // Add the available operation dropdowns
        const operationSelector = document.getElementById('operations_select');
        if (operationSelector != null) {
            operationSelector.addEventListener('change', function(event) {
                hideAllOperationFieldsets();
                showOperationFieldset(event.target.value);
            });
        }

        // Add the callback for the add operation button
        const operationAddButton = document.getElementById('operations_add_button');
        if (operationAddButton != null) {
            operationAddButton.addEventListener('click', function() {
                const newOperation = document.getElementById('operations_add_text').value.trim();

                if (newOperation == '') {
                    return;
                }

                addOperation(newOperation);
            });
        }

        // Add the callback for the JSON load button
        const authorizationLoadButton = document.getElementById('authorization_json_load');
        if (authorizationLoadButton != null) {
            authorizationLoadButton.addEventListener('click', function() {
                loadAuthorizationJson();
                updateAuthorizationJson();
            });
        }

        // Add the callbacks to the checkboxes
        const operationFieldsets = document.getElementsByClassName('operation_fieldset');
        if (operationFieldsets.length > 0) {
            for (var i = 0; i < operationFieldsets.length; i++) {
                const operationFieldset = operationFieldsets[i];
                addCallbacksToCheckboxes(operationFieldset);
            }
        }

        // Add the before_submit call to enable all the checkboxes; this means
        // the form will send the full set of selected cascading resources
        // instead of the top resource in the cascade
        const submitButton = document.getElementById('submit_authorization_state');
        if (submitButton != null) {
            submitButton.addEventListener('submit', function() {
                beforeSubmit();
                // prevent button from submitting anything
                return false;
            });
        }

        // Check the currently-authorized resources for each operation
        checkAuthorizedResources();
        // Initial json generation
        updateAuthorizationJson();
    });
}

initializeEdit();
