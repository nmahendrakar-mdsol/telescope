class Api::AuthorizationStatesController < ApplicationController
  protect_from_forgery with: :null_session
  before_action :validate_requester
  before_action :find_authorization_state, only: [:update]

  def update
    raw_desired_authorization_state = params.require(:authorization_json)
    desired_authorization_state = parse_authorization_state(raw_desired_authorization_state)

    @authorization_state.update_authorization_state!(desired_authorization_state)

    render json: {}, status: :no_content
  end

  private

  def parse_authorization_state(raw_parameter)
    parsed_json = JSON.parse(raw_parameter)

    unless parsed_json.is_a?(Hash)
      raise AuthorizationState::RecordInvalid, 'authorization_json must be valid json!'
    end

    parsed_json
  rescue JSON::ParserError
    raise AuthorizationState::RecordInvalid, 'authorization_json must be valid json!'
  end

  def find_authorization_state
    @authorization_state = AuthorizationState.find_or_create!(params[:id])
  end

  def validate_requester
    return if API_WHITELISTED_APP_UUIDS.include?(mauth_app_uuid)

    raise Unauthorized, "#{mauth_app_uuid} is not authorized for Telescope's Api"
  end

  def mauth_app_uuid
    request.env['mauth.app_uuid']
  end
end
