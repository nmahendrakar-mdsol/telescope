require 'rails_helper'
require 'protected_resource_types_helper'

RSpec.describe ProtectedResourceTypesHelper do
  let(:target) { Module.new.extend(ProtectedResourceTypesHelper) }

  describe '.all_resources' do
    let(:grandparent) { create(:protected_resource_type) }
    let(:parent) { create(:protected_resource_type, parents: [grandparent.oid]) }
    let(:sibling_a) { create(:protected_resource_type, parents: [parent.oid]) }
    let(:sibling_b) { create(:protected_resource_type, parents: [parent.oid]) }

    it 'returns the expected tree' do
      expected_tree = {
        grandparent.oid => {
          parent.oid => {
            sibling_a.oid => {},
            sibling_b.oid => {}
          }
        }
      }

      expect(target.all_resources).to eq(expected_tree)
    end

    it 'returns a ResourceTree' do
      expect(target.all_resources).to be_a(ResourceTree)
    end

    context 'when a parallel relationship exists between protected resource types ending in _collection' do
      let(:parent_collection) { create(:protected_resource_type, oid: parent.oid + '_collection') }
      let(:stepchild) { create(:protected_resource_type) }
      let!(:stepchild_collection) { create(:protected_resource_type, oid: stepchild.oid + '_collection', parents: [parent_collection.oid]) }

      it 'unifies the relationships into the tree' do
        expected_tree = {
          grandparent.oid => {
            parent.oid => {
              sibling_a.oid => {},
              sibling_b.oid => {},
              stepchild.oid => {}
            }
          }
        }

        expect(target.all_resources).to eq(expected_tree)
      end
    end
  end

  describe '.accessible_resources_for_resource' do
    let(:grandparent) { create(:protected_resource_type) }
    let(:parent) { create(:protected_resource_type, parents: [grandparent.oid]) }
    let(:sibling_a) { create(:protected_resource_type, parents: [parent.oid]) }
    let(:sibling_b) { create(:protected_resource_type, parents: [parent.oid]) }

    it 'returns a ResourceTree' do
      expect(target.accessible_resources_for_resource(parent.oid)).to be_a(ResourceTree)
    end

    it 'returns the protected resource tree beginning at the specified protected resource type oid' do
      expected_tree = {
        parent.oid => {
          sibling_a.oid => {},
          sibling_b.oid => {}
        }
      }

      expect(target.accessible_resources_for_resource(parent.oid)).to eq(expected_tree)
    end

    context 'when a parallel relationship exists between protected resource types ending in _collection' do
      let(:parent_collection) { create(:protected_resource_type, oid: parent.oid + '_collection') }
      let(:stepchild) { create(:protected_resource_type) }
      let!(:stepchild_collection) { create(:protected_resource_type, oid: stepchild.oid + '_collection', parents: [parent_collection.oid]) }

      it 'unified the relationships into the tree' do
        expected_tree = {
          parent.oid => {
            sibling_a.oid => {},
            sibling_b.oid => {},
            stepchild.oid => {}
          }
        }

        expect(target.accessible_resources_for_resource(parent.oid)).to eq(expected_tree)
      end
    end
  end
end
