require 'rails_helper'

RSpec.describe 'Authorization states API', type: :request do
  let(:app_uuid) { SecureRandom.uuid }

  before do
    telescope_uri = Mdsol::URI.generate(APP_UUID, resource: :apps).to_s
    create(:configuration_type, parent_uri: telescope_uri)

    allow_any_instance_of(Api::AuthorizationStatesController)
      .to receive(:mauth_app_uuid).and_return(app_uuid)
  end

  describe '/api/authorization_states/:id' do
    describe 'PUT' do
      subject { put "/api/authorization_states/#{app_uuid}", params: params }

      context 'when the requesting app is whitelisted' do
        before { stub_const('API_WHITELISTED_APP_UUIDS', [app_uuid]) }

        context 'when the request has an authorization_json parameter' do
          let(:authorization_state) do
            {
              'operation' => ['resource']
            }
          end

          let(:params) { { authorization_json: authorization_state.to_json } }

          it 'returns a 204 with no body' do
            subject
            expect(response.status).to eq(204)
            expect(response.body).to eq('')
          end

          it 'updates the specified authorization state' do
            dbl = double(:authorization_state)
            allow(AuthorizationState).to receive(:find_or_create!).with(app_uuid).and_return(dbl)
            expect(dbl).to receive(:update_authorization_state!).with(authorization_state)

            subject
          end

          context 'and the authorization_json does not contain valid json' do
            let(:authorization_state) { 'foo' }

            it 'returns a 422' do
              subject
              expect(response.status).to eq(422)
            end
          end
        end

        context 'when the request does not have an authorization_json parameter' do
          let(:params) { {} }

          it 'returns a 422' do
            subject
            expect(response.status).to eq(422)
          end
        end
      end

      context 'when the requesting app is not whitelisted' do
        before { stub_const('API_WHITELISTED_APP_UUIDS', []) }

        let(:params) { {} }

        it 'returns a 401' do
          subject
          expect(response.status).to eq(401)
        end
      end

      context 'when the request has an invalid mauth signature' do
        let(:params) { {} }

        # Mock a failed authentication
        before { MAuth::Rack::RequestAuthenticationFaker.authentic = false }

        it 'returns a 401' do
          subject
          expect(response.status).to eq(401)
        end
      end
    end
  end
end
