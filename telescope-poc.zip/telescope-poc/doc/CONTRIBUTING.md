# Contributing to Telescope

## Installation

1. Clone the repo:
   ```
   $ git clone git@github.com:mdsol/telescope.git
   $ cd telescope
   ```
2. Install dependencies with Bundler:
   ```
   $ bundle install
   ```
3. Configure dicebag files for Monitorwares:
   ```
   $ bundle exec rake config
   ```

## Usage

You can start the Telescope server by executing:
```
$ bundle exec rails server
```

You can access the local server at `localhost:3000`.

## Running Tests

Execute the following command to run the test suite:
```
$ bundle exec rspec
```
