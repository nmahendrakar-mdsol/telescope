def randomized_uri_for(resource)
  Mdsol::URI.generate(SecureRandom.uuid, resource: resource).to_s
end

def permission_for_operation(operation)
  { 'operation' => operation }
end

def collection_uri(resource)
  "com:mdsol:#{resource}_collection:all"
end

def role_assignment_exists?(operator_uri, role_uri, operable_uri)
  # Check RAs directly
  ra = Euresource::RoleAssignment.get_all(
    operator_uri: operator_uri,
    role_uri: role_uri,
    operable_uri: operable_uri
  )

  return true if ra.present?

  # fall back to checking grants manually, which imply a role assignment but
  # don't surface in mocked eureka client. because it's faked, we have to do
  # some shenanigans to pull grants out of the response
  grants = Euresource::Grant.get_all.flat_map(&:grants).map do |grant_params|
    Euresource::Grant.new(grant_params)
  end

  grants.any? do |grant|
    next unless grant.operator_uri == operator_uri

    grant.role_operable_pairs.any? do |role_operable_pair|
      role_operable_pair['configuration_type_role_uri'] == role_uri &&
        role_operable_pair['operable_uri'] == operable_uri
    end
  end
end
