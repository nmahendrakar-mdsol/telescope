# WARNING! Do not modify this file directly. It was generated from the
# 'mauth.rb.dice' template file.
#
# Use the rake config task to reconfigure. See the template file for
# further guidance.

MAUTH_CONF = MAuth::Client.default_config
MAUTH_CONF[:should_authenticate_check] = proc do |env|
  env['PATH_INFO'] =~ %r{\A/api|\A/smoke_test}
end

require 'mauth/rack'
# ResponseSigner OPTIONAL; only use if you are registered in mauth service
Rails.application.config.middleware.insert_after Rack::Runtime, MAuth::Rack::ResponseSigner, MAUTH_CONF
if Rails.env.test? || Rails.env.development?
  require 'mauth/fake/rack'
  Rails.application.config.middleware.insert_after MAuth::Rack::ResponseSigner, MAuth::Rack::RequestAuthenticationFaker, MAUTH_CONF
else
  Rails.application.config.middleware.insert_after MAuth::Rack::ResponseSigner, MAuth::Rack::RequestAuthenticatorNoAppStatus, MAUTH_CONF
end
