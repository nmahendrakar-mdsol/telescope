require 'rails_helper'

RSpec.describe 'Root', type: :request do
  describe '/' do
    describe 'GET' do
      subject { get '/' }

      it 'defers to authorization_states#index' do
        expect(subject).to render_template('authorization_states/index')
      end
    end
  end
end
