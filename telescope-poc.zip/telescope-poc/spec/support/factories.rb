FactoryBot.define do
  factory :authorization_state do
    app_uuid { create(:app).uuid }
    app_name { AuthorizationStateSource.app_name(app_uuid) }
    updated_at { Time.now.utc }
    available_resources { ResourceTree.new({}) }
    available_operations { [] }
    current_authorization_state { {} }
  end

  factory :app, class: Euresource::App do
    uuid { SecureRandom.uuid }
    name { uuid }
    role_required { true }
    category_oid { nil }
    oid { nil }
    multiple_roles { true }

    skip_create
    after(:create) { |instance| create_euresource(instance) }
  end

  factory :configuration_type, class: Euresource::ConfigurationType do
    uuid { SecureRandom.uuid }
    client_division_uuid { SecureRandom.uuid }
    configuration_type_uuids { [] }
    name { uuid }
    parent_uri { Mdsol::URI.generate(create(:app)).to_s }

    skip_create
    after(:create) { |instance| create_euresource(instance) }
  end

  factory :configuration_type_role, class: Euresource::ConfigurationTypeRole do
    uuid { SecureRandom.uuid }
    configuration_type_uuid { create(:configuration_type).uuid }
    configuration_type_role_uuids { [] }
    name { uuid }
    permissions { [] }
    prohibited_permissions { [] }
    read_only { false }
    role_category_oid { 'internal' }
    tags { [] }


    skip_create
    after(:create) { |instance| create_euresource(instance) }
  end

  factory :protected_resource_type, class: Euresource::ProtectedResourceType do
    uuid { SecureRandom.uuid }
    oid { uuid }
    members { [] }
    parents { [] }

    skip_create
    after(:create) { |instance| create_euresource(instance) }
  end

  factory :role_assignment, class: Euresource::RoleAssignment do
    uuid { SecureRandom.uuid }
    operator_uri { Mdsol::URI.generate(create(:app)).to_s }
    role_uri { Mdsol::URI.generate(create(:configuration_type_role)).to_s }
    operable_uri { collection_uri(create(:protected_resource_type).oid.pluralize) }

    skip_create
    after(:create) { |instance| create_euresource(instance) }
  end
end

def create_euresource(euresource)
  euresource.class.post!(euresource.attributes, method: :create)
end
