class ResourceTree
  def initialize(hash_tree)
    @hash_tree = hash_tree
  end

  def to_h
    @hash_tree
  end

  def to_a
    arr = []
    @hash_tree.deep_transform_keys { |key| arr |= [key] }
    arr
  end

  def ==(other)
    case other.class.to_s
    when 'ResourceTree'
      to_h == other.to_h
    when 'Hash'
      to_h == other
    else
      false
    end
  end
end
