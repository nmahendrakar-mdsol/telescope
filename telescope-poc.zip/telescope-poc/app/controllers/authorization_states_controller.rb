class AuthorizationStatesController < ApplicationController
  before_action :find_authorization_state, only: [:show, :edit, :update, :refresh]
  before_action :filter_ui_updates, only: [:edit, :update]

  def create
    @authorization_state = AuthorizationState.new(create_params)
    @authorization_state.save!
    redirect_to @authorization_state
  rescue AuthorizationState::RecordInvalid => e
    flash[:error] = "Error! #{e.message}"
    redirect_to authorization_states_path
  end

  def show
    respond_to do |format|
      format.html

      format.json do
        render json: @authorization_state, status: :ok
      end
    end
  end

  def edit
  end

  def update
    raw_desired_authorization_state = params.require(:authorization_json)
    desired_authorization_state = JSON.parse(raw_desired_authorization_state)

    @authorization_state.update_authorization_state!(desired_authorization_state)

    respond_to do |format|
      format.html do
        redirect_to edit_authorization_state_path(@authorization_state)
      end

      format.json do
        render json: {}, status: :no_content
      end
    end
  rescue AuthorizationState::UnableToUpdate => e
    respond_to do |format|
      format.html do
        flash[:error] = "Error! Unable to update state: #{e.message}"
        render :edit
      end

      format.json do
        render json: { 'errors' => e.message }, status: :unprocessable_entity
      end
    end
  end

  def index
    @authorization_states = AuthorizationState.all
  end

  def refresh
    @authorization_state.reload
    redirect_to request.referrer
  end

  private

  def create_params
    params.require(:authorization_state).permit(:app_uuid)
  end

  def find_authorization_state
    @authorization_state = AuthorizationState.find_or_create!(params[:id])
  end

  def filter_ui_updates
    return if ENABLE_UI_UPDATES

    render status: 404, body: nil
  end
end
