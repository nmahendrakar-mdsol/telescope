class ApplicationController < ActionController::Base
  Unauthorized = Class.new(StandardError)

  ERROR_STATUSES = {
    ActionController::ParameterMissing => :unprocessable_entity,
    AuthorizationState::RecordInvalid => :unprocessable_entity,
    Unauthorized => :unauthorized
  }.freeze

  rescue_from(StandardError) do |err|
    Rails.logger.exception(err, data: params.to_json)

    error_status = ERROR_STATUSES[err.class] || :internal_server_error
    error_message = if error_status == :internal_server_error
                      'Error message stored in logs'
                    else
                      err.message
                    end

    err_details = { status: error_status, message: error_message }
    err_hash = { 'errors' => [err_details] }

    expires_now
    respond_to do |format|
      format.json { render json: err_hash, status: error_status }
    end
  end
end
