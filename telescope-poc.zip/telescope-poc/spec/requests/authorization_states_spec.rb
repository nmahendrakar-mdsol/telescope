require 'rails_helper'

RSpec.describe 'Authorization states', type: :request do
  describe '/authorization_states' do
    describe 'GET' do
      subject { get '/authorization_states' }

      context 'when ENABLE_UI_UPDATES is set to true' do
        before { stub_const('ENABLE_UI_UPDATES', true ) }

        it 'renders the index template' do
          expect(subject).to render_template(:index)
        end
      end

      context 'when ENABLE_UI_UPDATES is set to false' do
        before { stub_const('ENABLE_UI_UPDATES', false ) }

        it 'renders the index template' do
          expect(subject).to render_template(:index)
        end
      end
    end

    describe 'POST' do
      let(:app_uuid) { SecureRandom.uuid }
      let(:params) do
        {
          authorization_state: {
            app_uuid: app_uuid
          }
        }
      end

      subject { post '/authorization_states', params: params }

      context 'when ENABLE_UI_UPDATES is set to true' do
        before { stub_const('ENABLE_UI_UPDATES', true ) }

        it 'creates an authorization state for the specified app uuid' do
          expect {
            subject
          }.to change {
            AuthorizationState.all.any? { |state| state.app_uuid = app_uuid }
          }.from(false).to(true)
        end

        it 'redirects to the show path for the specified app uuid' do
          expect(subject).to redirect_to(authorization_state_path(app_uuid))
        end
      end

      context 'when ENABLE_UI_UPDATES is set to false' do
        before { stub_const('ENABLE_UI_UPDATES', false ) }

        it 'creates an authorization state for the specified app uuid' do
          expect {
            subject
          }.to change {
            AuthorizationState.all.any? { |state| state.app_uuid = app_uuid }
          }.from(false).to(true)
        end

        it 'redirects to the show path for the specified app uuid' do
          expect(subject).to redirect_to(authorization_state_path(app_uuid))
        end
      end
    end
  end

  describe '/authorization_states/:id' do
    let(:app_uuid) { SecureRandom.uuid }

    describe 'GET' do
      subject { get "/authorization_states/#{app_uuid}" }

      context 'when ENABLE_UI_UPDATES is set to true' do
        before { stub_const('ENABLE_UI_UPDATES', true ) }

        context 'when the authorization state exists' do
          before { create(:authorization_state, app_uuid: app_uuid) }

          it 'renders the show template' do
            expect(subject).to render_template(:show)
          end
        end

        context 'when the authorization state does not exist' do
          it 'renders the show template' do
            expect(subject).to render_template(:show)
          end
        end
      end

      context 'when ENABLE_UI_UPDATES is set to false' do
        before { stub_const('ENABLE_UI_UPDATES', false ) }

        context 'when the authorization state exists' do
          before { create(:authorization_state, app_uuid: app_uuid) }

          it 'renders the show template' do
            expect(subject).to render_template(:show)
          end
        end

        context 'when the authorization state does not exist' do
          it 'renders the show template' do
            expect(subject).to render_template(:show)
          end
        end
      end
    end

    describe 'PATCH' do
      let(:authorization_state) { {} }
      let(:params) do
        {
          authorization_json: authorization_state.to_json
        }
      end

      subject { patch "/authorization_states/#{app_uuid}", params: params }

      context 'when ENABLE_UI_UPDATES is set to true' do
        before { stub_const('ENABLE_UI_UPDATES', true ) }

        context 'when the authorization state exists' do
          before { create(:authorization_state, app_uuid: app_uuid) }

          it 'updates the authorization state with the specified authorization state' do
            dbl = double(:authorization_state)
            allow(AuthorizationState).to receive(:find_or_create!).with(app_uuid).and_return(dbl)

            expect(dbl).to receive(:update_authorization_state!).with(authorization_state)
            subject
          end

          it 'redirects to the edit route for specified app uuid' do
            expect(subject).to redirect_to(edit_authorization_state_path(app_uuid))
          end
        end

        context 'when the authorization state does not exist' do
          it 'updates the authorization state with the specified authorization json' do
            dbl = double(:authorization_state)
            allow(AuthorizationState).to receive(:find_or_create!).with(app_uuid).and_return(dbl)

            expect(dbl).to receive(:update_authorization_state!).with(authorization_state)
            subject
          end

          it 'redirects to the edit route for the specified app uuid' do
            expect(subject).to redirect_to(edit_authorization_state_path(app_uuid))
          end
        end
      end

      context 'when ENABLE_UI_UPDATES is set to false' do
        before { stub_const('ENABLE_UI_UPDATES', false ) }

        it 'returns a 404' do
          subject
          expect(response.status).to eq(404)
        end

        it 'does not update any authorization state' do
          expect_any_instance_of(AuthorizationState).to_not receive(:update_authorization_state!)
          subject
        end
      end
    end

    describe 'PUT' do
      let(:authorization_state) { {} }
      let(:params) do
        {
          authorization_json: authorization_state.to_json
        }
      end

      subject { put "/authorization_states/#{app_uuid}", params: params }

      context 'when ENABLE_UI_UPDATES is set to true' do
        before { stub_const('ENABLE_UI_UPDATES', true ) }

        context 'when the authorization state exists' do
          before { create(:authorization_state, app_uuid: app_uuid) }

          it 'updates the authorization state with the specified authorization state' do
            dbl = double(:authorization_state)
            allow(AuthorizationState).to receive(:find_or_create!).with(app_uuid).and_return(dbl)

            expect(dbl).to receive(:update_authorization_state!).with(authorization_state)
            subject
          end

          it 'redirects to the edit route for specified app uuid' do
            expect(subject).to redirect_to(edit_authorization_state_path(app_uuid))
          end
        end

        context 'when the authorization state does not exist' do
          it 'updates the authorization state with the specified authorization json' do
            dbl = double(:authorization_state)
            allow(AuthorizationState).to receive(:find_or_create!).with(app_uuid).and_return(dbl)

            expect(dbl).to receive(:update_authorization_state!).with(authorization_state)
            subject
          end

          it 'redirects to the edit route for the specified app uuid' do
            expect(subject).to redirect_to(edit_authorization_state_path(app_uuid))
          end
        end
      end

      context 'when ENABLE_UI_UPDATES is set to false' do
        before { stub_const('ENABLE_UI_UPDATES', false ) }

        it 'returns a 404' do
          subject
          expect(response.status).to eq(404)
        end

        it 'does not update any authorization state' do
          expect_any_instance_of(AuthorizationState).to_not receive(:update_authorization_state!)
          subject
        end
      end
    end
  end

  describe '/authorization_states/:id/edit' do
    let(:app_uuid) { SecureRandom.uuid }

    describe 'GET' do
      subject { get "/authorization_states/#{app_uuid}/edit" }

      context 'when ENABLE_UI_UPDATES is set to true' do
        before { stub_const('ENABLE_UI_UPDATES', true ) }

        context 'when the authorization state exists' do
          before { create(:authorization_state, app_uuid: app_uuid) }

          it 'renders the edit template' do
            expect(subject).to render_template(:edit)
          end
        end

        context 'when the authorization state does not exist' do
          it 'renders the edit template' do
            expect(subject).to render_template(:edit)
          end
        end
      end

      context 'when ENABLE_UI_UPDATES is set to false' do
        before { stub_const('ENABLE_UI_UPDATES', false ) }

        it 'returns a 404' do
          subject
          expect(response.status).to eq(404)
        end
      end
    end
  end

  describe '/authorization_states/:id/refresh' do
    let(:app_uuid) { SecureRandom.uuid }

    describe 'POST' do
      let(:referrer) { SecureRandom.uuid }

      subject { post "/authorization_states/#{app_uuid}/refresh", headers: { 'HTTP_REFERER' => referrer } }

      context 'when ENABLE_UI_UPDATES is set to true' do
        before { stub_const('ENABLE_UI_UPDATES', true ) }

        context 'when the authorization state exists' do
          before { create(:authorization_state, app_uuid: app_uuid) }

          it 'reloads the authorization state' do
            dbl = double(:authorization_state)
            allow(AuthorizationState).to receive(:find_or_create!).with(app_uuid).and_return(dbl)

            expect(dbl).to receive(:reload)
            subject
          end

          it 'redirects to the referrer' do
            expect(subject).to redirect_to(referrer)
          end
        end

        context 'when the authorization state does not exist' do
          it 'reloads the authorization state' do
            dbl = double(:authorization_state)
            allow(AuthorizationState).to receive(:find_or_create!).with(app_uuid).and_return(dbl)

            expect(dbl).to receive(:reload)
            subject
          end

          it 'redirects to the referrer' do
            expect(subject).to redirect_to(referrer)
          end
        end
      end

      context 'when ENABLE_UI_UPDATES is set to false' do
        before { stub_const('ENABLE_UI_UPDATES', false ) }

        context 'when the authorization state exists' do
          before { create(:authorization_state, app_uuid: app_uuid) }

          it 'reloads the authorization state' do
            dbl = double(:authorization_state)
            allow(AuthorizationState).to receive(:find_or_create!).with(app_uuid).and_return(dbl)

            expect(dbl).to receive(:reload)
            subject
          end

          it 'redirects to the referrer' do
            expect(subject).to redirect_to(referrer)
          end
        end

        context 'when the authorization state does not exist' do
          it 'reloads the authorization state' do
            dbl = double(:authorization_state)
            allow(AuthorizationState).to receive(:find_or_create!).with(app_uuid).and_return(dbl)

            expect(dbl).to receive(:reload)
            subject
          end

          it 'redirects to the referrer' do
            expect(subject).to redirect_to(referrer)
          end
        end
      end
    end
  end
end
