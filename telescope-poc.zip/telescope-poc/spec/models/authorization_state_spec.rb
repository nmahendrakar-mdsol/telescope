require 'rails_helper'

RSpec.describe AuthorizationState do
  describe '.find_or_create!' do
    let(:app_uuid) { create(:app).uuid }

    context 'when an authorization state for the specified app has been saved' do
      let(:authorization_state) { build(:authorization_state, app_uuid: app_uuid) }

      before { authorization_state.save! }

      it 'loads the previously saved authorization state from cache' do
        expect(Rails.cache).to receive(:read).with(authorization_state.app_uuid).and_call_original
        expect_any_instance_of(AuthorizationState).to_not receive(:save!)

        result = AuthorizationState.find_or_create!(app_uuid)
        expect(result.attributes).to eq(authorization_state.attributes)
      end
    end

    context 'when an authorization state for the specified app has not been saved' do
      it 'creates the new authorization state' do
        double = double(:authorization_state)
        allow(double).to receive(:persisted?).and_return(false)
        allow(AuthorizationState).to receive(:new).with(app_uuid: app_uuid).and_return(double)

        expect(double).to receive(:save!)
        AuthorizationState.find_or_create!(app_uuid)
      end
    end
  end

  describe '.all' do
    context 'when an authorization state has been saved' do
      let!(:authorization_state) { create(:authorization_state) }

      it 'returns an array including the saved authorization state' do
        expect(AuthorizationState.all).to eq([authorization_state])
      end
    end

    context 'when no authorization states have been saved' do
      it 'returns an empty array' do
        expect(AuthorizationState.all).to eq([])
      end
    end
  end

  describe '#save!' do
    let(:app) { create(:app) }
    let(:authorization_state) { AuthorizationState.new(app_uuid: app.uuid) }

    it 'calculates the current authorization' do
      expect(AuthorizationStateSource).to receive(:current_authorization).with(authorization_state.app_uuid)
      authorization_state.save!
    end

    it 'calculates the available resources' do
      expect(AuthorizationStateSource).to receive(:all_resources)
      authorization_state.save!
    end

    it 'calculates the available operations' do
      expect(AuthorizationStateSource).to receive(:cached_operations)
      authorization_state.save!
    end

    it 'has the app name' do
      authorization_state.save!
      expect(authorization_state.app_name).to eq(app.name)
    end

    it 'marks as persisted' do
      expect {
        authorization_state.save!
      }.to change {
        authorization_state.persisted?
      }.from(false).to(true)
    end

    it 'sets the updated_at' do
      time = Time.now.utc
      allow(Time).to receive(:now).and_return(time)

      authorization_state.save!

      expect(authorization_state.updated_at).to eq(time)
    end

    context 'when there is a euresource error fetching the app' do
      before do
        allow(Euresource::App).to receive(:get).and_raise(Euresource::ResourceNotFound.new(nil))
      end

      it 'does not error' do
        expect { authorization_state.save! }.to_not raise_error
      end
    end
  end

  describe '#update_authorization_state!' do
    let(:authorization_state) { create(:authorization_state) }
    let(:desired_authorization_state) do
      { 'read' => ['apps'] }
    end

    it 'tells the authorization state source to manage the state appropriately' do
      expect(AuthorizationStateSource)
        .to receive(:manage_authorization_state!)
        .with(
        authorization_state.app_uuid,
        desired_authorization_state: desired_authorization_state
      )

      authorization_state.update_authorization_state!(desired_authorization_state)
    end
  end

  describe '#destroy' do
    let(:authorization_state) { build(:authorization_state) }

    context 'when the authorization state has been saved' do
      before { authorization_state.save! }

      it 'removes the authorization state from the cache' do
        expect {
          authorization_state.destroy
        }.to change {
          AuthorizationState.all
        }.from([authorization_state]).to([])
      end
    end

    context 'when the authorization state has not been saved' do
      it 'does not error' do
        expect { authorization_state.destroy }.to_not raise_error
      end
    end
  end

  describe '#persisted?' do
    let(:authorization_state) { build(:authorization_state) }

    context 'when the authorization state has been saved' do
      before { authorization_state.save! }

      it 'returns true' do
        expect(authorization_state.persisted?).to eq(true)
      end
    end

    context 'when the authorization state has not been saved' do
      it 'returns false' do
        expect(authorization_state.persisted?).to eq(false)
      end
    end
  end

  describe '#attributes' do
    let(:authorization_state) { build(:authorization_state) }

    [
      :app_uuid,
      :app_name,
      :available_resources,
      :available_operations,
      :current_authorization_state
    ].each do |desired_attribute|
      it "includes #{desired_attribute}" do
        attribute_value = authorization_state.attributes[desired_attribute]
        desired_value = authorization_state.send(desired_attribute)

        expect(attribute_value).to eq(desired_value)
      end
    end
  end

  describe '#reload' do
    let(:authorization_state) { create(:authorization_state) }

    context 'when an attribute is out of sync' do
      let(:attribute) { :app_name }

      it 'syncs the attribute' do
        accurate_value = authorization_state.send(attribute)
        inaccurate_value = SecureRandom.uuid

        authorization_state.send("#{attribute}=", inaccurate_value)

        expect {
          authorization_state.reload
        }.to change {
          authorization_state.app_name
        }.from(inaccurate_value).to(accurate_value)
      end
    end
  end

  describe '#available_resources' do
    let(:authorization_state) { AuthorizationState.new(app_uuid: SecureRandom.uuid) }

    it 'fetches the available resources from the authorization state source' do
      expect(AuthorizationStateSource).to receive(:all_resources)
      authorization_state.available_resources
    end
  end

  describe '#available_operations' do
    let(:authorization_state) { AuthorizationState.new(app_uuid: SecureRandom.uuid) }

    it 'fetches the available operations from the authorization state source' do
      expect(AuthorizationStateSource).to receive(:cached_operations)
      authorization_state.available_operations
    end
  end

  describe '#app_name' do
    context 'when the app exists externally' do
      let(:app_uuid) { create(:app).uuid }
      let(:authorization_state) { AuthorizationState.new(app_uuid: app_uuid) }

      it 'fetches the app name from the authorization state source' do
        expect(AuthorizationStateSource).to receive(:app_name).with(app_uuid)
        authorization_state.app_name
      end
    end

    context 'when the app does not exist externally' do
      let(:authorization_state) { AuthorizationState.new(app_uuid: SecureRandom.uuid) }

      it 'returns the app uuid' do
        expect(authorization_state.app_name).to eq authorization_state.app_uuid
      end
    end
  end

  describe '#current_authorization_state' do
    let(:authorization_state) { AuthorizationState.new(app_uuid: SecureRandom.uuid) }

    it 'fetches the current authorization state from the authorization state source' do
      expect(AuthorizationStateSource).to receive(:current_authorization).with(authorization_state.app_uuid)
      authorization_state.current_authorization_state
    end
  end

  describe '#==' do
    let(:authorization_state) { build(:authorization_state) }

    context 'when comparing an authorization state with the same attributes' do
      let(:similar_authorization_state) { authorization_state.dup }

      it 'returns true' do
        expect(authorization_state == similar_authorization_state).to eq(true)
      end
    end

    context 'when comparing an authorization state with different attributes' do
      let(:other_authorization_state) { build(:authorization_state) }

      it 'returns false' do
        expect(authorization_state == other_authorization_state).to eq(false)
      end
    end

    context 'when comparing other types of objects' do
      it 'returns false' do
        expect(authorization_state == 1).to eq(false)
      end
    end
  end
end
