require 'protected_resource_types_helper'

module AuthorizationStateSource
  extend ProtectedResourceTypesHelper

  UnexpectedState = Class.new(StandardError)

  class << self
    # *whistles* just for testing
    def clear_memoizations!
      @configuration_type = nil
      @protected_resource_types = nil
      @real_protected_resource_types = nil
    end

    def app_name(app_uuid)
      Euresource::App.get(app_uuid).name
    rescue Euresource::ResourceNotFound
      app_uuid
    end

    def manage_authorization_state!(app_uuid, desired_authorization_state:)
      desired_authorization_state.reject! { |_, resources| resources.empty? }

      msg = "Beginning to manage authorization state for app: '#{app_uuid}', " \
        "desired authorization state: '#{desired_authorization_state}'"
      Rails.logger.info(msg)


      validate_authorization_state!(desired_authorization_state)

      app_uri = Mdsol::URI.generate(app_uuid, resource: :apps).to_s

      desired_role_operable_pairs = generate_role_operable_pairs(desired_authorization_state)
      current_role_operable_pairs = role_assignments_for_app_uri(app_uri).each_with_object([]) do |ra, memo|
        role_operable_pair = ra.attributes.symbolize_keys.slice(:role_uri, :operable_uri)
        memo.push(role_operable_pair)
      end

      msg = "Desired role operable pairs: '#{desired_role_operable_pairs}', " \
        "current role operable pairs: '#{current_role_operable_pairs}'"
      Rails.logger.info(msg)

      role_operable_pairs_to_create = desired_role_operable_pairs - current_role_operable_pairs
      role_operable_pairs_to_delete = current_role_operable_pairs - desired_role_operable_pairs

      create_grant!(app_uri, role_operable_pairs_to_create) if role_operable_pairs_to_create.present?
      destroy_assignments!(app_uri, role_operable_pairs_to_delete)
    end

    def current_authorization(app_uuid)
      app_uri = Mdsol::URI.generate(app_uuid, resource: :apps).to_s

      current_role_assignments = role_assignments_for_app_uri(app_uri)

      # { operation => resource_array }
      current_role_assignments.each_with_object({}) do |ra, memo|
        role_uri = ra.role_uri
        operable_uri = ra.operable_uri

        resource = resource_for_collection_uri(operable_uri)

        accessible_resources = accessible_resources_for_resource(resource).to_a
        operations = operations_for_role_uri(role_uri)

        operations.each do |operation|
          memo[operation] ||= []
          memo[operation] |= accessible_resources
        end
      end
    end

    def cached_operations
      Rails.cache.read('cached_operations') || []
    end

    def role_uri_for_operation!(operation)
      role_for_operation = all_roles.find do |role|
        role.permissions.any? do |permission|
          permission['operation'] == operation
        end
      end

      role_for_operation ||= create_role_for_operation!(operation)

      Mdsol::URI.generate(role_for_operation).to_s
    end

    private

    def create_grant!(app_uri, role_operable_pairs)
      # Change RA :role_uri key to Grant :configuration_type_role_uri key
      all_grant_role_operable_pairs = role_operable_pairs.map do |role_operable_pair|
        {
          operable_uri: role_operable_pair[:operable_uri],
          configuration_type_role_uri: role_operable_pair[:role_uri]
        }
      end

      # TODO: parallelize
      all_grant_role_operable_pairs.each_slice(50) do |grant_role_operable_pairs|
        grant_params = { grants: [{ operator_uri: app_uri, role_operable_pairs: grant_role_operable_pairs }] }

        # TODO: Handle more error cases
        begin
          Rails.logger.info("Creating grant with params: #{grant_params}")
          Euresource::Grant.post!(grant_params)
          Rails.logger.info("Successfully created grant with params: #{grant_params}")
        rescue Euresource::ResourceInvalid => e
          msg = "Error creating grant with params: #{grant_params}!"
          Rails.logger.error("#{msg}, #{e.class}, #{e.message}")
          raise UnexpectedState, msg
        end
      end
    end

    def destroy_assignments!(app_uri, role_operable_pairs)
      role_operable_pairs.each do |role_operable_pair|
        find_params = role_operable_pair.merge(operator_uri: app_uri)

        ras = Euresource::RoleAssignment.get_all(find_params)

        if ras.count != 1
          msg = "Expected 1 role assignment for #{find_params}, found #{ras.count}!"
          Rails.logger.error(msg)
        end

        ra = ras.first

        if ra.read_only
          msg = "Tried to delete read-only role assignment with uuid '#{ra.uuid}', skipping"
          Rails.logger.info(msg)
          next
        end

        msg = "Deleting role assignment with uuid '#{ra.uuid}'"
        Rails.logger.info(msg)
        Euresource::RoleAssignment.delete(ra.uuid)
      rescue => e
        msg = "Error deleting role assignment with uuid '#{ra.uuid}', skipping. #{e.class} #{e.method}"
        Rails.logger.info(msg)
      end
    end

    def validate_authorization_state!(authorization_state)
      # all operations valid?
      # others?
    end

    def generate_role_operable_pairs(authorization_state)
      authorization_state.flat_map do |operation, resources|
        role_uri = role_uri_for_operation!(operation)

        resources.flat_map do |resource|
          {
            role_uri: role_uri,
            operable_uri: "com:mdsol:#{resource}_collection:all"
          }
        end
      end
    end

    def all_roles
      Euresource::ConfigurationTypeRole.get_all(configuration_type_uuid: configuration_type.uuid)
    end

    def create_role_for_operation!(operation)
      permission = permission_for_operation(operation)

      msg = "Creating role for operation '#{operation}' for " \
        "configuration type uuid: '#{configuration_type.uuid}', " \
        "name: '#{operation}', permission: '#{permission}'"
      Rails.logger.info(msg)

      # TODO: Handle errors
      Euresource::ConfigurationTypeRole.post!(
        configuration_type_uuid: configuration_type.uuid,
        name: operation,
        permissions: [permission],
        role_category_oid: 'internal'
      )
    end

    def configuration_type
      @configuration_type ||=
        begin
          telescope_uri = Mdsol::URI.generate(APP_UUID, resource: :apps).to_s
          # TODO: Handle not created?
          Euresource::ConfigurationType.get_all(parent_uri: telescope_uri).first
        end
    end

    def permission_for_operation(operation)
      { operation: operation }
    end

    def add_operation_to_cache(operation)
      return if cached_operations.include?(operation)

      new_operations = cached_operations | [operation]
      Rails.cache.write('cached_operations', new_operations, expires_in: 1.month)
    end

    def role_assignments_for_app_uri(app_uri)
      Euresource::RoleAssignment.get_all(operator_uri: app_uri).select do |role_assignment|
        # Ignore assignments to specific operables
        operable_uri = role_assignment.operable_uri
        uri_is_collection?(operable_uri)
      end
    end

    def operations_for_role_uri(role_uri)
      role_uuid = Mdsol::URI.parse(role_uri).uuid

      # TODO: Handle not found?
      role = Euresource::ConfigurationTypeRole.get(role_uuid)
      role.permissions.map do |permission|
        operation = permission['operation']

        # register the operation while we're in here
        add_operation_to_cache(operation)
        operation
      end
    end

    def uri_is_collection?(uri)
      parsed_uri = Mdsol::URI.parse(uri)
      parsed_uri.resource.end_with?('_collection') && parsed_uri.uuid.eql?('all')
    end

    def resource_for_collection_uri(uri)
      unless uri_is_collection?(uri)
        msg = "Expected all collection URI, got #{uri}"
        Rails.logger.info(msg)
        return
      end

      Mdsol::URI.parse(uri).resource.delete_suffix('_collection')
    end
  end
end
